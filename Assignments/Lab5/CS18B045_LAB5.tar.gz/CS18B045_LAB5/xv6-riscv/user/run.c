#include "kernel/param.h"
#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/riscv.h"
#include "user/user.h"
void main(){
	 printf("x=%d y=%d "); 
	 exit(0);
}
